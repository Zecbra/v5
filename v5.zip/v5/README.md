# INSTAL SCRIPT
<pre><code>wget https://raw.githubusercontent.com/IlhamStore23/v5/main/meteor.sh && chmod +x meteor.sh && ./meteor.sh</code></pre>
